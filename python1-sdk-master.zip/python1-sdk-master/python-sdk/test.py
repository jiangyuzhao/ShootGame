import os
fp = open("/Users/qinyuxuan/Desktop/result.txt","w")
fp.close()
